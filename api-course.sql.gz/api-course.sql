-- Adminer 4.8.1 MySQL 5.5.5-10.6.12-MariaDB-0ubuntu0.22.04.1 dump

SET NAMES utf8;
SET time_zone = '+00:00';
SET foreign_key_checks = 0;
SET sql_mode = 'NO_AUTO_VALUE_ON_ZERO';

SET NAMES utf8mb4;

DROP TABLE IF EXISTS `ads`;
CREATE TABLE `ads` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(255) DEFAULT NULL,
  `slug` varchar(255) DEFAULT NULL,
  `text` text DEFAULT NULL,
  `phone` varchar(255) DEFAULT NULL,
  `status` tinyint(4) NOT NULL DEFAULT 1,
  `user_id` bigint(20) unsigned DEFAULT NULL,
  `domain_id` int(10) unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `ads_user_id_foreign` (`user_id`),
  KEY `ads_domain_id_foreign` (`domain_id`),
  CONSTRAINT `ads_domain_id_foreign` FOREIGN KEY (`domain_id`) REFERENCES `domains` (`id`) ON DELETE SET NULL,
  CONSTRAINT `ads_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `ads` (`id`, `title`, `slug`, `text`, `phone`, `status`, `user_id`, `domain_id`, `created_at`, `updated_at`) VALUES
(1,	'hi ahmad',	'-1',	NULL,	NULL,	1,	NULL,	1,	'2024-01-14 06:20:34',	'2024-01-14 06:20:34'),
(2,	'hi ahmad2',	'-2',	NULL,	NULL,	1,	NULL,	1,	'2024-01-14 06:20:34',	'2024-01-14 06:20:34'),
(3,	NULL,	'-3',	NULL,	NULL,	1,	NULL,	NULL,	'2024-01-14 06:20:34',	'2024-01-14 06:20:34'),
(4,	NULL,	'-4',	NULL,	NULL,	1,	NULL,	NULL,	'2024-01-14 06:20:34',	'2024-01-14 06:20:34'),
(5,	NULL,	'-5',	NULL,	NULL,	1,	NULL,	NULL,	'2024-01-14 06:20:34',	'2024-01-14 06:20:34'),
(6,	NULL,	'-6',	NULL,	NULL,	1,	NULL,	NULL,	'2024-01-14 06:20:34',	'2024-01-14 06:20:34'),
(7,	NULL,	'-7',	NULL,	NULL,	1,	NULL,	NULL,	'2024-01-14 06:20:34',	'2024-01-14 06:20:34'),
(8,	NULL,	'-8',	NULL,	NULL,	1,	NULL,	NULL,	'2024-01-14 06:20:34',	'2024-01-14 06:20:34'),
(9,	NULL,	'-9',	NULL,	NULL,	1,	NULL,	NULL,	'2024-01-14 06:20:34',	'2024-01-14 06:20:34'),
(10,	NULL,	'-10',	NULL,	NULL,	1,	NULL,	NULL,	'2024-01-14 06:20:34',	'2024-01-14 06:20:34'),
(11,	NULL,	'-11',	NULL,	NULL,	1,	NULL,	NULL,	'2024-01-14 06:20:34',	'2024-01-14 06:20:34'),
(12,	NULL,	'-12',	NULL,	NULL,	1,	NULL,	NULL,	'2024-01-14 06:20:34',	'2024-01-14 06:20:34'),
(13,	'hi ahmad3',	'-13',	NULL,	NULL,	1,	NULL,	NULL,	'2024-01-14 06:20:34',	'2024-01-14 06:20:34'),
(14,	NULL,	'-14',	NULL,	NULL,	1,	NULL,	NULL,	'2024-01-14 06:20:35',	'2024-01-14 06:20:35'),
(15,	'hi mohammad',	'-15',	NULL,	NULL,	1,	NULL,	NULL,	'2024-01-14 06:20:35',	'2024-01-14 06:20:35'),
(16,	NULL,	'-16',	NULL,	NULL,	1,	NULL,	NULL,	'2024-01-14 06:20:35',	'2024-01-14 06:20:35'),
(17,	'hi mohammad1',	'-17',	NULL,	NULL,	1,	NULL,	NULL,	'2024-01-14 06:20:35',	'2024-01-14 06:20:35'),
(18,	NULL,	'-18',	NULL,	NULL,	1,	NULL,	NULL,	'2024-01-14 06:20:35',	'2024-01-14 06:20:35'),
(19,	NULL,	'-19',	NULL,	NULL,	1,	NULL,	NULL,	'2024-01-14 06:20:35',	'2024-01-14 06:20:35'),
(20,	NULL,	'-20',	NULL,	NULL,	1,	NULL,	NULL,	'2024-01-14 06:20:35',	'2024-01-14 06:20:35'),
(23,	'sherbeen updated',	'sherbeen-updated',	'this istest from ahmad and post man',	'0123456789',	1,	52,	1,	'2024-01-14 17:41:58',	'2024-01-14 17:41:58'),
(24,	'sherbeen second',	'sherbeen-second',	'this istest from ahmad and post man',	'0123456789',	1,	52,	1,	'2024-01-14 17:42:44',	'2024-01-14 17:42:44');

DROP TABLE IF EXISTS `cities`;
CREATE TABLE `cities` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `cities_name_unique` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `cities` (`id`, `name`, `created_at`, `updated_at`) VALUES
(101,	'cairo',	'2024-01-03 08:43:49',	'2024-01-03 08:43:49'),
(102,	'alex',	'2024-01-03 08:43:49',	'2024-01-03 08:43:49'),
(103,	'mansoura',	'2024-01-03 08:43:49',	'2024-01-03 08:43:49'),
(104,	NULL,	'2024-01-03 08:43:49',	'2024-01-03 08:43:49'),
(105,	NULL,	'2024-01-03 08:43:49',	'2024-01-03 08:43:49'),
(106,	NULL,	'2024-01-03 08:43:49',	'2024-01-03 08:43:49'),
(107,	NULL,	'2024-01-03 08:43:49',	'2024-01-03 08:43:49'),
(108,	NULL,	'2024-01-03 08:43:49',	'2024-01-03 08:43:49'),
(109,	NULL,	'2024-01-03 08:43:49',	'2024-01-03 08:43:49'),
(110,	NULL,	'2024-01-03 08:43:49',	'2024-01-03 08:43:49'),
(111,	NULL,	'2024-01-03 08:43:49',	'2024-01-03 08:43:49'),
(112,	NULL,	'2024-01-03 08:43:49',	'2024-01-03 08:43:49'),
(113,	NULL,	'2024-01-03 08:43:49',	'2024-01-03 08:43:49'),
(114,	NULL,	'2024-01-03 08:43:49',	'2024-01-03 08:43:49'),
(115,	NULL,	'2024-01-03 08:43:49',	'2024-01-03 08:43:49'),
(116,	NULL,	'2024-01-03 08:43:49',	'2024-01-03 08:43:49'),
(117,	NULL,	'2024-01-03 08:43:49',	'2024-01-03 08:43:49'),
(118,	NULL,	'2024-01-03 08:43:49',	'2024-01-03 08:43:49'),
(119,	NULL,	'2024-01-03 08:43:49',	'2024-01-03 08:43:49'),
(120,	NULL,	'2024-01-03 08:43:49',	'2024-01-03 08:43:49'),
(121,	NULL,	'2024-01-03 08:43:49',	'2024-01-03 08:43:49'),
(122,	NULL,	'2024-01-03 08:43:49',	'2024-01-03 08:43:49'),
(123,	NULL,	'2024-01-03 08:43:49',	'2024-01-03 08:43:49'),
(124,	NULL,	'2024-01-03 08:43:49',	'2024-01-03 08:43:49'),
(125,	NULL,	'2024-01-03 08:43:49',	'2024-01-03 08:43:49'),
(126,	NULL,	'2024-01-03 08:43:49',	'2024-01-03 08:43:49'),
(127,	NULL,	'2024-01-03 08:43:49',	'2024-01-03 08:43:49'),
(128,	NULL,	'2024-01-03 08:43:49',	'2024-01-03 08:43:49'),
(129,	NULL,	'2024-01-03 08:43:49',	'2024-01-03 08:43:49'),
(130,	NULL,	'2024-01-03 08:43:49',	'2024-01-03 08:43:49'),
(131,	NULL,	'2024-01-03 08:43:49',	'2024-01-03 08:43:49'),
(132,	NULL,	'2024-01-03 08:43:49',	'2024-01-03 08:43:49'),
(133,	NULL,	'2024-01-03 08:43:49',	'2024-01-03 08:43:49'),
(134,	NULL,	'2024-01-03 08:43:49',	'2024-01-03 08:43:49'),
(135,	NULL,	'2024-01-03 08:43:49',	'2024-01-03 08:43:49'),
(136,	NULL,	'2024-01-03 08:43:49',	'2024-01-03 08:43:49'),
(137,	NULL,	'2024-01-03 08:43:49',	'2024-01-03 08:43:49'),
(138,	NULL,	'2024-01-03 08:43:49',	'2024-01-03 08:43:49'),
(139,	NULL,	'2024-01-03 08:43:49',	'2024-01-03 08:43:49'),
(140,	NULL,	'2024-01-03 08:43:49',	'2024-01-03 08:43:49'),
(141,	NULL,	'2024-01-03 08:43:49',	'2024-01-03 08:43:49'),
(142,	NULL,	'2024-01-03 08:43:49',	'2024-01-03 08:43:49'),
(143,	NULL,	'2024-01-03 08:43:49',	'2024-01-03 08:43:49'),
(144,	NULL,	'2024-01-03 08:43:49',	'2024-01-03 08:43:49'),
(145,	NULL,	'2024-01-03 08:43:49',	'2024-01-03 08:43:49'),
(146,	NULL,	'2024-01-03 08:43:49',	'2024-01-03 08:43:49'),
(147,	NULL,	'2024-01-03 08:43:49',	'2024-01-03 08:43:49'),
(148,	NULL,	'2024-01-03 08:43:49',	'2024-01-03 08:43:49'),
(149,	NULL,	'2024-01-03 08:43:49',	'2024-01-03 08:43:49'),
(150,	NULL,	'2024-01-03 08:43:49',	'2024-01-03 08:43:49');

DROP TABLE IF EXISTS `districts`;
CREATE TABLE `districts` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `city_id` int(10) unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `districts_city_id_foreign` (`city_id`),
  CONSTRAINT `districts_city_id_foreign` FOREIGN KEY (`city_id`) REFERENCES `cities` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `districts` (`id`, `name`, `city_id`, `created_at`, `updated_at`) VALUES
(1,	'giza',	101,	'2024-01-03 08:57:42',	'2024-01-03 08:57:42'),
(2,	'semoha',	102,	'2024-01-03 08:57:42',	'2024-01-03 08:57:42'),
(3,	'sherbin',	103,	'2024-01-03 08:57:42',	'2024-01-03 08:57:42'),
(4,	'haram',	101,	'2024-01-03 08:57:42',	'2024-01-03 08:57:42'),
(5,	'tahrir',	101,	'2024-01-03 08:57:42',	'2024-01-03 08:57:42'),
(6,	NULL,	NULL,	'2024-01-03 08:57:42',	'2024-01-03 08:57:42'),
(7,	NULL,	NULL,	'2024-01-03 08:57:42',	'2024-01-03 08:57:42'),
(8,	NULL,	NULL,	'2024-01-03 08:57:42',	'2024-01-03 08:57:42'),
(9,	NULL,	NULL,	'2024-01-03 08:57:42',	'2024-01-03 08:57:42'),
(10,	NULL,	NULL,	'2024-01-03 08:57:42',	'2024-01-03 08:57:42'),
(11,	NULL,	NULL,	'2024-01-03 08:57:42',	'2024-01-03 08:57:42'),
(12,	NULL,	NULL,	'2024-01-03 08:57:42',	'2024-01-03 08:57:42'),
(13,	NULL,	NULL,	'2024-01-03 08:57:42',	'2024-01-03 08:57:42'),
(14,	NULL,	NULL,	'2024-01-03 08:57:42',	'2024-01-03 08:57:42'),
(15,	NULL,	NULL,	'2024-01-03 08:57:42',	'2024-01-03 08:57:42'),
(16,	NULL,	NULL,	'2024-01-03 08:57:42',	'2024-01-03 08:57:42'),
(17,	NULL,	NULL,	'2024-01-03 08:57:42',	'2024-01-03 08:57:42'),
(18,	NULL,	NULL,	'2024-01-03 08:57:42',	'2024-01-03 08:57:42'),
(19,	NULL,	NULL,	'2024-01-03 08:57:42',	'2024-01-03 08:57:42'),
(20,	NULL,	NULL,	'2024-01-03 08:57:42',	'2024-01-03 08:57:42'),
(21,	NULL,	NULL,	'2024-01-03 08:57:42',	'2024-01-03 08:57:42'),
(22,	NULL,	NULL,	'2024-01-03 08:57:42',	'2024-01-03 08:57:42'),
(23,	NULL,	NULL,	'2024-01-03 08:57:42',	'2024-01-03 08:57:42'),
(24,	NULL,	NULL,	'2024-01-03 08:57:42',	'2024-01-03 08:57:42'),
(25,	NULL,	NULL,	'2024-01-03 08:57:42',	'2024-01-03 08:57:42'),
(26,	NULL,	NULL,	'2024-01-03 08:57:42',	'2024-01-03 08:57:42'),
(27,	NULL,	NULL,	'2024-01-03 08:57:42',	'2024-01-03 08:57:42'),
(28,	NULL,	NULL,	'2024-01-03 08:57:42',	'2024-01-03 08:57:42'),
(29,	NULL,	NULL,	'2024-01-03 08:57:42',	'2024-01-03 08:57:42'),
(30,	NULL,	NULL,	'2024-01-03 08:57:42',	'2024-01-03 08:57:42'),
(31,	NULL,	NULL,	'2024-01-03 08:57:42',	'2024-01-03 08:57:42'),
(32,	NULL,	NULL,	'2024-01-03 08:57:42',	'2024-01-03 08:57:42'),
(33,	NULL,	NULL,	'2024-01-03 08:57:42',	'2024-01-03 08:57:42'),
(34,	NULL,	NULL,	'2024-01-03 08:57:42',	'2024-01-03 08:57:42'),
(35,	NULL,	NULL,	'2024-01-03 08:57:42',	'2024-01-03 08:57:42'),
(36,	NULL,	NULL,	'2024-01-03 08:57:42',	'2024-01-03 08:57:42'),
(37,	NULL,	NULL,	'2024-01-03 08:57:42',	'2024-01-03 08:57:42'),
(38,	NULL,	NULL,	'2024-01-03 08:57:42',	'2024-01-03 08:57:42'),
(39,	NULL,	NULL,	'2024-01-03 08:57:42',	'2024-01-03 08:57:42'),
(40,	NULL,	NULL,	'2024-01-03 08:57:42',	'2024-01-03 08:57:42'),
(41,	NULL,	NULL,	'2024-01-03 08:57:42',	'2024-01-03 08:57:42'),
(42,	NULL,	NULL,	'2024-01-03 08:57:42',	'2024-01-03 08:57:42'),
(43,	NULL,	NULL,	'2024-01-03 08:57:42',	'2024-01-03 08:57:42'),
(44,	NULL,	NULL,	'2024-01-03 08:57:42',	'2024-01-03 08:57:42'),
(45,	NULL,	NULL,	'2024-01-03 08:57:42',	'2024-01-03 08:57:42'),
(46,	NULL,	NULL,	'2024-01-03 08:57:42',	'2024-01-03 08:57:42'),
(47,	NULL,	NULL,	'2024-01-03 08:57:42',	'2024-01-03 08:57:42'),
(48,	NULL,	NULL,	'2024-01-03 08:57:42',	'2024-01-03 08:57:42'),
(49,	NULL,	NULL,	'2024-01-03 08:57:42',	'2024-01-03 08:57:42'),
(50,	NULL,	NULL,	'2024-01-03 08:57:42',	'2024-01-03 08:57:42');

DROP TABLE IF EXISTS `domains`;
CREATE TABLE `domains` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `status` tinyint(4) NOT NULL DEFAULT 1,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `domains_name_unique` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `domains` (`id`, `name`, `status`, `created_at`, `updated_at`) VALUES
(1,	'مبدعون وافراد',	0,	'2024-01-03 07:53:09',	'2024-01-03 07:53:09');

DROP TABLE IF EXISTS `failed_jobs`;
CREATE TABLE `failed_jobs` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `uuid` varchar(255) NOT NULL,
  `connection` text NOT NULL,
  `queue` text NOT NULL,
  `payload` longtext NOT NULL,
  `exception` longtext NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


DROP TABLE IF EXISTS `media`;
CREATE TABLE `media` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `model_type` varchar(255) NOT NULL,
  `model_id` bigint(20) unsigned NOT NULL,
  `uuid` char(36) DEFAULT NULL,
  `collection_name` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `file_name` varchar(255) NOT NULL,
  `mime_type` varchar(255) DEFAULT NULL,
  `disk` varchar(255) NOT NULL,
  `conversions_disk` varchar(255) DEFAULT NULL,
  `size` bigint(20) unsigned NOT NULL,
  `manipulations` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL CHECK (json_valid(`manipulations`)),
  `custom_properties` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL CHECK (json_valid(`custom_properties`)),
  `generated_conversions` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL CHECK (json_valid(`generated_conversions`)),
  `responsive_images` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL CHECK (json_valid(`responsive_images`)),
  `order_column` int(10) unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `media_uuid_unique` (`uuid`),
  KEY `media_model_type_model_id_index` (`model_type`,`model_id`),
  KEY `media_order_column_index` (`order_column`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


DROP TABLE IF EXISTS `messages`;
CREATE TABLE `messages` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `phone` varchar(255) DEFAULT NULL,
  `message` text DEFAULT NULL,
  `status` tinyint(4) NOT NULL DEFAULT 0,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `messages` (`id`, `name`, `email`, `phone`, `message`, `status`, `created_at`, `updated_at`) VALUES
(1,	'ahmad othman',	'ahmad@mail.com',	'0123456789',	'this isform data test',	0,	'2024-01-07 12:42:41',	'2024-01-07 12:42:41'),
(2,	'ahmad othman',	'ahmad@mail.com',	'0123456789',	'this isform data test',	0,	'2024-01-07 12:43:49',	'2024-01-07 12:43:49');

DROP TABLE IF EXISTS `migrations`;
CREATE TABLE `migrations` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `migration` varchar(255) NOT NULL,
  `batch` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1,	'2014_10_12_000000_create_users_table',	1),
(2,	'2014_10_12_100000_create_password_resets_table',	1),
(3,	'2019_08_19_000000_create_failed_jobs_table',	1),
(4,	'2019_12_14_000001_create_personal_access_tokens_table',	1),
(5,	'2022_12_27_062805_create_permission_tables',	1),
(6,	'2022_12_27_063242_create_permission_groups_table',	1),
(7,	'2022_12_27_210454_create_media_table',	1),
(8,	'2022_12_28_185625_create_domains_table',	1),
(9,	'2022_12_29_062522_create_messages_table',	1),
(10,	'2022_12_29_064635_create_settings_table',	1),
(11,	'2023_01_05_105329_add_google_id_to_users_table',	1),
(12,	'2023_01_12_194838_create_ads_table',	1),
(13,	'2023_01_14_114643_create_cities_table',	1),
(14,	'2023_01_14_120238_create_districts_table',	1),
(15,	'2023_01_14_155920_add_activity_terms_to_settings_table',	1),
(16,	'2023_01_18_150629_add_phone_to_users_table',	1),
(17,	'2023_01_19_190452_add_fields_to_settings_table',	1),
(18,	'2023_01_21_070318_add_ad_links_to_settings_table',	1);

DROP TABLE IF EXISTS `model_has_permissions`;
CREATE TABLE `model_has_permissions` (
  `permission_id` bigint(20) unsigned NOT NULL,
  `model_type` varchar(255) NOT NULL,
  `model_id` bigint(20) unsigned NOT NULL,
  PRIMARY KEY (`permission_id`,`model_id`,`model_type`),
  KEY `model_has_permissions_model_id_model_type_index` (`model_id`,`model_type`),
  CONSTRAINT `model_has_permissions_permission_id_foreign` FOREIGN KEY (`permission_id`) REFERENCES `permissions` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


DROP TABLE IF EXISTS `model_has_roles`;
CREATE TABLE `model_has_roles` (
  `role_id` bigint(20) unsigned NOT NULL,
  `model_type` varchar(255) NOT NULL,
  `model_id` bigint(20) unsigned NOT NULL,
  PRIMARY KEY (`role_id`,`model_id`,`model_type`),
  KEY `model_has_roles_model_id_model_type_index` (`model_id`,`model_type`),
  CONSTRAINT `model_has_roles_role_id_foreign` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


DROP TABLE IF EXISTS `password_resets`;
CREATE TABLE `password_resets` (
  `email` varchar(255) NOT NULL,
  `token` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  KEY `password_resets_email_index` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


DROP TABLE IF EXISTS `permissions`;
CREATE TABLE `permissions` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `guard_name` varchar(255) NOT NULL,
  `group_id` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `permissions_name_guard_name_unique` (`name`,`guard_name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


DROP TABLE IF EXISTS `permission_groups`;
CREATE TABLE `permission_groups` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `value` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


DROP TABLE IF EXISTS `personal_access_tokens`;
CREATE TABLE `personal_access_tokens` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `tokenable_type` varchar(255) NOT NULL,
  `tokenable_id` bigint(20) unsigned NOT NULL,
  `name` varchar(255) NOT NULL,
  `token` varchar(64) NOT NULL,
  `abilities` text DEFAULT NULL,
  `last_used_at` timestamp NULL DEFAULT NULL,
  `expires_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `personal_access_tokens_token_unique` (`token`),
  KEY `personal_access_tokens_tokenable_type_tokenable_id_index` (`tokenable_type`,`tokenable_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `personal_access_tokens` (`id`, `tokenable_type`, `tokenable_id`, `name`, `token`, `abilities`, `last_used_at`, `expires_at`, `created_at`, `updated_at`) VALUES
(10,	'App\\Models\\User',	52,	'course',	'992350788b8e0a5b2da4d38605aa3f8d7b2f926dc27505198690f5b2ea197f1c',	'[\"*\"]',	'2024-01-14 17:42:52',	NULL,	'2024-01-14 13:13:54',	'2024-01-14 17:42:52');

DROP TABLE IF EXISTS `roles`;
CREATE TABLE `roles` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `guard_name` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `roles_name_guard_name_unique` (`name`,`guard_name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


DROP TABLE IF EXISTS `role_has_permissions`;
CREATE TABLE `role_has_permissions` (
  `permission_id` bigint(20) unsigned NOT NULL,
  `role_id` bigint(20) unsigned NOT NULL,
  PRIMARY KEY (`permission_id`,`role_id`),
  KEY `role_has_permissions_role_id_foreign` (`role_id`),
  CONSTRAINT `role_has_permissions_permission_id_foreign` FOREIGN KEY (`permission_id`) REFERENCES `permissions` (`id`) ON DELETE CASCADE,
  CONSTRAINT `role_has_permissions_role_id_foreign` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


DROP TABLE IF EXISTS `settings`;
CREATE TABLE `settings` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `about_us` text DEFAULT NULL,
  `why_us` text DEFAULT NULL,
  `goal` text DEFAULT NULL,
  `vision` text DEFAULT NULL,
  `about_footer` text DEFAULT NULL,
  `ads_text` text DEFAULT NULL,
  `activities_text` text DEFAULT NULL,
  `persons_text` text DEFAULT NULL,
  `contact_us_text` text DEFAULT NULL,
  `terms_text` text DEFAULT NULL,
  `activity_terms` text DEFAULT NULL,
  `counter1_name` varchar(255) DEFAULT NULL,
  `counter1_count` bigint(20) DEFAULT NULL,
  `counter2_name` varchar(255) DEFAULT NULL,
  `counter2_count` bigint(20) DEFAULT NULL,
  `counter3_name` varchar(255) DEFAULT NULL,
  `counter3_count` bigint(20) DEFAULT NULL,
  `counter4_name` varchar(255) DEFAULT NULL,
  `counter4_count` bigint(20) DEFAULT NULL,
  `address1` varchar(255) DEFAULT NULL,
  `address2` varchar(255) DEFAULT NULL,
  `phone1` varchar(255) DEFAULT NULL,
  `phone2` varchar(255) DEFAULT NULL,
  `whatsapp1` varchar(255) DEFAULT NULL,
  `whatsapp2` varchar(255) DEFAULT NULL,
  `email1` varchar(255) DEFAULT NULL,
  `email2` varchar(255) DEFAULT NULL,
  `facebook` varchar(255) DEFAULT NULL,
  `linkedin` varchar(255) DEFAULT NULL,
  `instagram` varchar(255) DEFAULT NULL,
  `youtube` varchar(255) DEFAULT NULL,
  `twitter` varchar(255) DEFAULT NULL,
  `pinterest` varchar(255) DEFAULT NULL,
  `map` text DEFAULT NULL,
  `google_play` varchar(255) DEFAULT NULL,
  `app_store` varchar(255) DEFAULT NULL,
  `ad_link_1` varchar(255) DEFAULT NULL,
  `ad_link_2` varchar(255) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `settings` (`id`, `about_us`, `why_us`, `goal`, `vision`, `about_footer`, `ads_text`, `activities_text`, `persons_text`, `contact_us_text`, `terms_text`, `activity_terms`, `counter1_name`, `counter1_count`, `counter2_name`, `counter2_count`, `counter3_name`, `counter3_count`, `counter4_name`, `counter4_count`, `address1`, `address2`, `phone1`, `phone2`, `whatsapp1`, `whatsapp2`, `email1`, `email2`, `facebook`, `linkedin`, `instagram`, `youtube`, `twitter`, `pinterest`, `map`, `google_play`, `app_store`, `ad_link_1`, `ad_link_2`, `created_at`, `updated_at`) VALUES
(1,	'this is us',	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	'Subscriptions',	100,	'Cities Office',	50,	'Worker',	200,	'Happy Clients',	500,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	'2024-01-03 07:53:09',	'2024-01-03 07:53:09'),
(2,	'',	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	'Subscriptions',	100,	'Cities Office',	50,	'Worker',	200,	'Happy Clients',	500,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	'2024-01-03 07:57:24',	'2024-01-03 07:57:24');

DROP TABLE IF EXISTS `users`;
CREATE TABLE `users` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `phone` varchar(255) DEFAULT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) NOT NULL,
  `remember_token` varchar(100) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `google_id` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_email_unique` (`email`),
  UNIQUE KEY `users_phone_unique` (`phone`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `users` (`id`, `name`, `email`, `phone`, `email_verified_at`, `password`, `remember_token`, `created_at`, `updated_at`, `google_id`) VALUES
(52,	'ahmad',	'ahmad@email.com',	NULL,	NULL,	'$2y$10$t3EjWb8uncF.7Gy5T0E0FOU8f/rqEpCEKC5cD4TJh1xqAtaBbuPq2',	NULL,	'2024-01-08 07:29:06',	'2024-01-08 07:29:06',	NULL);

-- 2024-01-15 11:08:14
